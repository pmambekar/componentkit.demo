package com.company.talend.components.service;

import org.talend.sdk.component.api.service.Service;

@Service
public class ComponentkitDemoService {

    // you can put logic here you can reuse in components

}