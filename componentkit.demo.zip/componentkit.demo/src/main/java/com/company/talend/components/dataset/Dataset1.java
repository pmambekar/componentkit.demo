package com.company.talend.components.dataset;

import java.io.Serializable;

import com.company.talend.components.datastore.Datastore1;

import org.talend.sdk.component.api.configuration.Option;
import org.talend.sdk.component.api.configuration.type.DataSet;
import org.talend.sdk.component.api.configuration.ui.layout.GridLayout;
import org.talend.sdk.component.api.meta.Documentation;

@DataSet("Dataset1")
@GridLayout({
    // the generated layout put one configuration entry per line,
    // customize it as much as needed
    @GridLayout.Row({ "datastore" })
})
@Documentation("TODO fill the documentation for this configuration")
public class Dataset1 implements Serializable {
    @Option
    @Documentation("TODO fill the documentation for this parameter")
    private Datastore1 datastore;

    public Datastore1 getDatastore() {
        return datastore;
    }

    public Dataset1 setDatastore(Datastore1 datastore) {
        this.datastore = datastore;
        return this;
    }
}